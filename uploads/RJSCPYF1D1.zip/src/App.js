import {Component} from 'react'

import GameContainer from './components/GameContainer'

import GameContext from './GameContext/index'

import './App.css'

const choicesList = [
  {
    id: 'ROCK',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rock-paper-scissor/rock-image.png',
  },
  {
    id: 'SCISSORS',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rock-paper-scissor/scissor-image.png',
  },
  {
    id: 'PAPER',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rock-paper-scissor/paper-image.png',
  },
]

const gameContants = {
  newGame: 'NEW GAME',
  loss: 'YOU LOSE',
  win: 'YOU WON',
  draw: 'IT IS DRAW',
}

class App extends Component {
  state = {
    score: 0,
    userChoice: '',
    systemChoice: '',
    gameStatus: gameContants.newGame,
  }

  componentDidMount() {
    this.systemSelectedChoice()
  }

  systemSelectedChoice = () => {
    const randomIndex = Math.floor(Math.random() * choicesList.length)
    this.setState({systemChoice: choicesList[randomIndex].id})
  }

  userSelectedChoice = choice => {
    const {systemChoice} = this.state
    let gameStatus
    if (choice === systemChoice) {
      gameStatus = gameContants.draw
    } else if (
      (choice === 'ROCK' && systemChoice === 'SCISSORS') ||
      (choice === 'PAPER' && systemChoice === 'ROCK') ||
      (choice === 'SCISSORS' && systemChoice === 'PAPER')
    ) {
      gameStatus = gameContants.win
    } else {
      gameStatus = gameContants.loss
    }

    if (gameStatus === gameContants.win) {
      this.setState(prevState => ({
        gameStatus,
        userChoice: choice,
        score: prevState.score + 1,
      }))
    } else if (gameStatus === gameContants.draw) {
      this.setState({
        gameStatus,
        userChoice: choice,
      })
    } else {
      this.setState(prevState => ({
        gameStatus,
        userChoice: choice,
        score: prevState.score - 1,
      }))
    }
  }

  onClickNewGame = () => {
    this.setState(
      {userChoice: '', gameStatus: gameContants.newGame},
      this.systemSelectedChoice,
    )
  }

  render() {
    const {userChoice, systemChoice, gameStatus, score} = this.state
    return (
      <GameContext.Provider
        value={{
          choicesList,
          score,
          userSelectedChoice: this.userSelectedChoice,
          userChoice,
          systemChoice,
          gameStatus,
          onClickNewGame: this.onClickNewGame,
        }}
      >
        <GameContainer />
      </GameContext.Provider>
    )
  }
}

export default App
