import Header from '../Header'
import Profile from '../Profile'

const Jobs = () => (
  <div>
    <Header />
    <div>
      <Profile />
    </div>
  </div>
)

export default Jobs
