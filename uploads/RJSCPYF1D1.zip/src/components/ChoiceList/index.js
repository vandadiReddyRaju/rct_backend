import GameContext from '../../GameContext/index'

import {
  ChoiceImageContainer,
  ChoiceImage,
  ButtonElement,
} from './ChoiceStyledComponent'
import './index.css'

const ChoiceList = () => (
  <GameContext.Consumer>
    {value => {
      const {choicesList, userSelectedChoice} = value
      const onClickChoice = choice => {
        userSelectedChoice(choice)
      }

      return (
        <div className="game-choice-container">
          <ul className="choice-container">
            <li className="choice-list">
              <ChoiceImageContainer>
                <ButtonElement
                  type="button"
                  onClick={() => onClickChoice(choicesList[0].id)}
                  data-testid="rockButton"
                >
                  <ChoiceImage
                    src={choicesList[0].imageUrl}
                    alt={choicesList[0].id}
                  />
                </ButtonElement>
              </ChoiceImageContainer>
              <ChoiceImageContainer>
                <ButtonElement
                  type="button"
                  onClick={() => onClickChoice(choicesList[1].id)}
                  data-testid="paperButton"
                >
                  <ChoiceImage
                    src={choicesList[1].imageUrl}
                    alt={choicesList[1].id}
                  />
                </ButtonElement>
              </ChoiceImageContainer>
            </li>
            <li className="choice-list">
              <ChoiceImageContainer>
                <ButtonElement
                  type="button"
                  onClick={() => onClickChoice(choicesList[2].id)}
                  data-testid="scissorsButton"
                >
                  <ChoiceImage
                    src={choicesList[2].imageUrl}
                    alt={choicesList[2].id}
                  />
                </ButtonElement>
              </ChoiceImageContainer>
            </li>
          </ul>
        </div>
      )
    }}
  </GameContext.Consumer>
)

export default ChoiceList
