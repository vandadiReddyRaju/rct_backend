// Write your code here
import {Components} from 'react'
import './index.css'

class ClickCounter extends Components {
  state = {count: 0}
  // onIncrement = () => {
  //   this.setState(prevState => {
  //     console.log(`'previous state value ${prevState.count}'`)
  //     return {count:prevState.count + 1}
  //   })
  // }

  render() {
    const {count} = this.state
    return (
      <div className="container">
        <p className="heading">The Button has been clickrd {count} times</p>
        <p className="text">Click the button to increase the count!</p>
        <button className="button">Check Me!</button>
      </div>
    )
  }
}
export default ClickCounter
