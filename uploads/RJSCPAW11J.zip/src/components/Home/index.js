import './index.css'
import Header from '../Header'
import {Link} from 'react-router-dom'

const Home = () => {
  return (
    <div>
      <Header />
      <div className="home-container">
        <h1 className="title">
          Find The Job That <br />
          Fits Your Life
        </h1>
        <p className="description">
          Millions of people are searching for jobs, salary
          <br /> information comapny reviews. Find the job that fits your <br />
          abilities and potentials
        </p>
<Link to='/jobs'>
        <button className="btn btn-primary">Find Jobs</button></Link>
      </div>
    </div>
  )
}
export default Home
