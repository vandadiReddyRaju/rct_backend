import GameContext from '../../GameContext/index'

import {ScoreParagraph} from '../ChoiceList/ChoiceStyledComponent'

import './index.css'

const ScoreTable = () => (
  <GameContext.Consumer>
    {value => {
      const {score} = value

      return (
        <div className="score-table">
          <h1 className="choice-heading">
            ROCK <br /> PAPER <br /> SCISSORS
          </h1>
          <div className="score-board">
            <p className="score-text">Score</p>
            <ScoreParagraph>{score}</ScoreParagraph>
          </div>
        </div>
      )
    }}
  </GameContext.Consumer>
)

export default ScoreTable
