import Styled from 'styled-components'

export const ChoiceImageContainer = Styled.div`
    width: 180px;
`

export const ButtonElement = Styled.button`
    background-color: #00000000;
    border: 0px;
`

export const ChoiceImage = Styled.img`
    width:100%;
`

export const GameStatusHeading = Styled.h1`
    color: #ffffff;
    font-weight: bold;
    font-size: 23px;
`
export const ScoreParagraph = Styled.p`
  color: #223a5f;
  font-size: 25px;
  font-weight: bold;
  margin-bottom: 5px;
  margin-top: 0px;
  font-family: 'Roboto';
`
