# Routing using react-router Part 3

- Navigating to Specific Blog
  - using Path Parameters
- Path Params
  - match
