import './index.css'
import {Component} from 'react'
import Cookies from 'js-cookie'

class Profile extends Component {
  state = {
    userProfileData: [],
  }

  componentDidMount() {
    this.userProfile()
  }

  userProfile = async () => {
    const token = Cookies.get('jwt_token')
    const Url = 'https://apis.ccbp.in/profile'
    const options = {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
    const response = await fetch(Url, options)
    if (response.ok === true) {
      const fetchedData = await response.json()
      console.log(fetchedData)
      const formattedUserData = fetchedData.map(eachData => ({
        name: eachData.name,
        profileImageUrl: eachData.profile_image_url,
        shortBio: eachData.short_bio,
      }))
      this.setState({userProfileData: formattedUserData})
    }
  }

  render() {
    const {userProfileData} = this.state

    return (
      <div className="profile-container">
        <img src="" alt="profile-img" />
        <h1>Mahesh Kammari</h1>
        <p>Lead software Developer and AI-ML expert</p>
      </div>
    )
  }
}
export default Profile
