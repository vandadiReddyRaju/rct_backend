import {BsSearch} from 'react-icons/bs'

const FiltersGroup = props => {
  const onEnterSearchInput = event => {
    const {enterSearchInput} = props
    if (event.key === 'Enter') {
      enterSearchInput()
    }
  }

  const onChangeSearchInput = event => {
    const {changeSearchInput} = props
    changeSearchInput(event.target.value)
  }

  const renderSearchInput = () => {
    const {searchInput} = props
    return (
      <div className="search-input-container">
        <input
          value={searchInput}
          type="search"
          id="search"
          className="search-input"
          placeholder="Search"
          onChange={onChangeSearchInput}
          onKeyDown={onEnterSearchInput}
        />
        <button type="button" data-testid="searchButton">
          <label htmlFor="search">
            <BsSearch className="search-icon" />
          </label>
        </button>
      </div>
    )
  }

  const renderSalaryRangeList = () => {
    const {salaryRangesList} = props
    return salaryRangesList.map(salary => {
      const {changeSalary} = props

      const onClickSalary = () => changeSalary(salary.salaryRangeId)
      return (
        <li key={salary.salaryRangeId} onClick={onClickSalary}>
          <p>{salary.label}</p>
        </li>
      )
    })
  }

  const renderSalaryRange = () => (
    <div>
      <h1>Salary Range</h1>
      <ul>{renderSalaryRangeList()}</ul>
    </div>
  )

  const renderEmploymentTypeList = () => {
    const {employmentTypesList} = props
    return employmentTypesList.map(each => {
      const {changeEmploy} = props

      const onChangeEmploy = () => changeEmploy(each.employmentTypeId)
      return (
        <li key={each.employmentTypeId} onClick={onChangeEmploy}>
          <input id="checkbox" type="checkbox" />
          <label htmlFor="checkbox">{each.label}</label>
        </li>
      )
    })
  }

  const renderEmploymentType = () => (
    <div>
      <h1>Emploment</h1>
      <ul>{renderEmploymentTypeList()}</ul>
    </div>
  )

  const {clearFilters} = props

  return (
    <div className="filters-group-container">
      {renderSearchInput()}
      {renderSalaryRange()}
      {renderEmploymentType()}
      <button
        type="button"
        className="clear-filters-btn"
        onClick={clearFilters}
      >
        Clear Filters
      </button>
    </div>
  )
}

export default FiltersGroup
