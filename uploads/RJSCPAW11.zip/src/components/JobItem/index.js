import {Link} from 'react-router-dom'

const JobItem = props => {
  const {jobDetails} = props
  const {
    jobDescription,
    packagePerAnnum,
    location,
    employmentType,
    companyLogoUrl,
    rating,
    title,
    id,
  } = jobDetails

  return (
    <Link to={`/jobs/${id}`}>
      <li>
        <div>
          <img alt="company logo" src={companyLogoUrl} />
          <h1>{title}</h1>
          <p>{rating}</p>
          <p>{employmentType}</p>
          <p>{location}</p>
          <h1>Description</h1>
          <p>{jobDescription}</p>
          <p>{packagePerAnnum}</p>
        </div>
      </li>
    </Link>
  )
}
export default JobItem
