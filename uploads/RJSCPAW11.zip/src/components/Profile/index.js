import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'

const submitStatus = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class Profile extends Component {
  state = {profile: {}, apiStatus: submitStatus.initial}

  componentDidMount() {
    this.getComponent()
  }

  getComponent = async () => {
    this.setState({apiStatus: submitStatus.inProgress})

    const url = 'https://apis.ccbp.in/profile'
    const token = Cookies.get('jwt_token')
    const options = {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
    const response = await fetch(url, options)
    if (response.ok === true) {
      const data = await response.json()
      const updatedData = {
        name: data.profile_details.name,
        profileImageUrl: data.profile_details.profile_image_url,
        shortBio: data.profile_details.short_bio,
      }
      this.setState({profile: updatedData, apiStatus: submitStatus.success})
    } else if (response.status === 401) {
      this.setState({apiStatus: submitStatus.failure})
    }
  }

  renderSuccessView = () => {
    const {profile} = this.state
    const {name, profileImageUrl, shortBio} = profile
    return (
      <div>
        <h1>{name}</h1>
        <img alt="profile" src={profileImageUrl} />
        <p>{shortBio}</p>
      </div>
    )
  }

  renderFailureView = () => (
    <div>
      <button type="button">Retry</button>
    </div>
  )

  renderLoaderView = () => (
    <div>
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  render() {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case submitStatus.success:
        return this.renderSuccessView()

      case submitStatus.failure:
        return this.renderFailureView()

      case submitStatus.inProgress:
        return this.renderLoaderView()

      default:
        return null
    }
  }
}
export default Profile
