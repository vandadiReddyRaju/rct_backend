import {Link, withRouter} from 'react-router-dom'
import Cookies from 'js-cookie'

const Header = props => {
  const onLogout = () => {
    const {history} = props
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <div>
      <Link to="/">
        <li>
          <img
            alt="website logo"
            src="https://assets.ccbp.in/frontend/react-js/logo-img.png"
          />
        </li>
      </Link>
      <div>
        <Link to="/">
          <li>
            <p>Home</p>
          </li>
        </Link>
        <Link to="/jobs">
          <li>
            <p>Jobs</p>
          </li>
        </Link>
      </div>
      <button onClick={onLogout} type="button">
        Logout
      </button>
    </div>
  )
}
export default withRouter(Header)
