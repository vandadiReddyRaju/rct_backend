import {Link, Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

import Header from '../Header'
import './index.css'

const Home = () => {
  const token = Cookies.get('jwt_token')
  if (token === undefined) {
    return <Redirect to="/login" />
  }
  return (
    <div className="back-ground">
      <ul>
        <Header />
      </ul>
      <h1>Find The Job That Fits Your Life</h1>
      <p>
        Millions of people are searching for jobs, slaery information, compeny
        reviews. Find the that fits your abilities and potential
      </p>
      <Link to="/jobs">
        <button type="button">Find Jobs</button>
      </Link>
    </div>
  )
}
export default Home
