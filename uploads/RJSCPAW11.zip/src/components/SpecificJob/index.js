const SpecificJob = props => {
  const {jobDetails} = props

  return (
    <div>
      <p>hi</p>
    </div>
  )
}
export default SpecificJob
