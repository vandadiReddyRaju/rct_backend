import {Component} from 'react'

import Cookies from 'js-cookie'

import './index.css'

class Login extends Component {
  state = {username: '', password: '', errMsg: '', isErrorOccured: false}

  onChanegUsername = event => {
    this.setState({username: event.target.value})
  }

  onChanegPassword = event => {
    this.setState({password: event.target.value})
  }

  submitSuccess = jwtToken => {
    const {history} = this.props
    Cookies.set('jwt_token', jwtToken, {expires: 30})
    history.replace('/')
  }

  submitFailure = errMsg => {
    this.setState({errMsg, isErrorOccured: true})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}

    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }

    const response = await fetch(url, options)
    const data = await response.json()

    if (response.ok === true) {
      this.submitSuccess(data.jwt_token)
    } else {
      this.submitFailure(data.error_msg)
    }
  }

  render() {
    const {username, password, errMsg, isErrorOccured} = this.state
    return (
      <div className="login">
        <form onSubmit={this.submitForm} className="form">
          <img
            alt="website logo"
            src="https://assets.ccbp.in/frontend/react-js/logo-img.png"
          />
          <div>
            <label htmlFor="username">Username</label>
            <input
              onChange={this.onChanegUsername}
              value={username}
              id="username"
              type="text"
            />
          </div>
          <div>
            <label htmlFor="password">Password</label>
            <input
              onChange={this.onChanegPassword}
              value={password}
              id="password"
              type="password"
            />
          </div>
          <button type="submit">Login</button>
        </form>
        {isErrorOccured && <p>{errMsg}</p>}
      </div>
    )
  }
}
export default Login
