const UserProfile = () => (
    <div><img src="https://assets.ccbp.in/frontend/react-js/esther-howard-img.png"/ ></div>
)

export default UserProfile;