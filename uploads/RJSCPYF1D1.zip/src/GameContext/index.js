import React from 'react'

const GameContext = React.createContext({
  choicesList: [],
  score: 0,
  userSelectedChoice: () => {},
  userChoice: '',
  systemChoice: '',
  gameStatus: 'NEW GAME',
  onClickNewGame: () => {},
})

export default GameContext
