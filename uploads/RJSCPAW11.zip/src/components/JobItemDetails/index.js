import {Component} from 'react'
import Cookies from 'js-cookie'

import './index.css'

class JobItemDetails extends Component {
  componentDidMount() {
    this.getJobItemDetails()
  }

  getJobItemDetails = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params

    const token = Cookies.get('jwt_token')
    const url = `https://apis.ccbp.in/jobs/${id}`
    const options = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      method: 'GET',
    }
    const response = await fetch(url, options)
    console.log(response)
    if (response.ok === true) {
      const data = await response.json()

      console.log(data)
    }
  }

  render() {
    return (
      <div className="color">
        <h1>hi</h1>
      </div>
    )
  }
}
export default JobItemDetails
