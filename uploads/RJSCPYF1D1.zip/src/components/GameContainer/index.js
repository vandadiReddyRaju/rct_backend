import GameContext from '../../GameContext/index'
import ScoreTable from '../ScoreTable'
import ChoiceList from '../ChoiceList/index'
import Rules from '../Rules'

import {
  ChoiceImage,
  GameStatusHeading,
  ChoiceImageContainer,
} from '../ChoiceList/ChoiceStyledComponent'

import './index.css'

const gameContants = {
  newGame: 'NEW GAME',
  loss: 'YOU LOSE',
  win: 'YOU WON',
  draw: 'IT IS DRAW',
}

const GameContainer = () => (
  <GameContext.Consumer>
    {value => {
      const renderGameStatusPage = gameStatus => {
        const {userChoice, systemChoice, choicesList, onClickNewGame} = value
        const userSelectedChoice = choicesList.find(
          choice => choice.id === userChoice,
        )

        const systemSelectedChoice = choicesList.find(
          choice => choice.id === systemChoice,
        )
        return (
          <>
            <ul className="game-status-list-container">
              <li className="user-choice">
                <GameStatusHeading>You</GameStatusHeading>
                {userSelectedChoice !== undefined && (
                  <ChoiceImageContainer>
                    <ChoiceImage
                      src={userSelectedChoice.imageUrl}
                      alt="your choice"
                    />
                  </ChoiceImageContainer>
                )}
              </li>
              <li className="system-choice">
                <GameStatusHeading>Opponent</GameStatusHeading>
                {systemSelectedChoice !== undefined && (
                  <ChoiceImageContainer>
                    <ChoiceImage
                      src={systemSelectedChoice.imageUrl}
                      alt="opponent choice"
                    />
                  </ChoiceImageContainer>
                )}
              </li>
            </ul>
            <div className="score-play-again-container">
              <p className="game-status-text">{gameStatus}</p>
              <button
                type="button"
                className="play-again"
                onClick={onClickNewGame}
              >
                PLAY AGAIN
              </button>
            </div>
          </>
        )
      }

      const renderNewGame = () => (
        <>
          <ChoiceList />
        </>
      )

      const renderReleventData = () => {
        const {gameStatus} = value
        console.log(gameStatus)
        switch (gameStatus) {
          case gameContants.win:
          case gameContants.loss:
          case gameContants.draw:
            return renderGameStatusPage(gameStatus)
          case gameContants.newGame:
            return renderNewGame()
          default:
            return null
        }
      }

      return (
        <div className="game-container">
          <div className="score-table-container">
            <ScoreTable />
          </div>
          {renderReleventData()}
          <Rules />
        </div>
      )
    }}
  </GameContext.Consumer>
)

export default GameContainer
