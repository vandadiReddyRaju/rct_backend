import Popup from 'reactjs-popup'

import {RiCloseLine} from 'react-icons/ri'

import './index.css'

const Rules = () => (
  <div className="rules-btn-container">
    <Popup
      trigger={
        <button type="button" className="rules-btn">
          Rules
        </button>
      }
      modal
    >
      {close => (
        <div className="popup-content">
          <button
            type="button"
            className="trigger-button"
            onClick={() => close()}
          >
            <RiCloseLine className="close-icon" />
          </button>
          <img
            src="https://assets.ccbp.in/frontend/react-js/rock-paper-scissor/rules-image.png"
            alt="rules"
            className="rules-img"
          />
        </div>
      )}
    </Popup>
  </div>
)

export default Rules
