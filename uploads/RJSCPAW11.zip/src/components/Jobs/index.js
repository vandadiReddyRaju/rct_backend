import {Component} from 'react'
import {Redirect} from 'react-router-dom'
import Loader from 'react-loader-spinner'

import Cookies from 'js-cookie'
import FiltersGroup from '../FiltersGroup'
import JobItem from '../JobItem'
import Profile from '../Profile'
import Header from '../Header'
import './index.css'

const submitStatus = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

const employmentTypesList = [
  {
    label: 'Full Time',
    employmentTypeId: 'FULLTIME',
  },
  {
    label: 'Part Time',
    employmentTypeId: 'PARTTIME',
  },
  {
    label: 'Freelance',
    employmentTypeId: 'FREELANCE',
  },
  {
    label: 'Internship',
    employmentTypeId: 'INTERNSHIP',
  },
]

const salaryRangesList = [
  {
    salaryRangeId: '1000000',
    label: '10 LPA and above',
  },
  {
    salaryRangeId: '2000000',
    label: '20 LPA and above',
  },
  {
    salaryRangeId: '3000000',
    label: '30 LPA and above',
  },
  {
    salaryRangeId: '4000000',
    label: '40 LPA and above',
  },
]

class Jobs extends Component {
  state = {
    jobsList: [],
    apiStatus: submitStatus.initial,
    activeSalaryId: '',
    activeEmployeId: '',
    searchInput: '',
  }

  componentDidMount() {
    this.getComponent()
  }

  getComponent = async () => {
    this.setState({apiStatus: submitStatus.inProgress})
    const {searchInput, activeEmployeId, activeSalaryId} = this.state

    const url = `https://apis.ccbp.in/jobs?employment_type=${activeEmployeId}&minimum_package=${activeSalaryId}&search=${searchInput}`
    const token = Cookies.get('jwt_token')
    const options = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      method: 'GET',
    }

    const response = await fetch(url, options)
    if (response.ok === true) {
      const data = await response.json()
      const updatedList = data.jobs.map(each => ({
        id: each.id,
        title: each.title,
        rating: each.rating,
        companyLogoUrl: each.company_logo_url,
        employmentType: each.employment_type,
        jobDescription: each.job_description,
        location: each.location,
        packagePerAnnum: each.package_per_annum,
      }))
      this.setState({jobsList: updatedList, apiStatus: submitStatus.success})
    } else if (response.status === 401) {
      this.setState({apiStatus: submitStatus.failure})
    }
  }

  clearFilters = () => {
    this.setState(
      {activeSalaryId: '', activeEmployeId: '', searchInput: ''},
      this.getComponent,
    )
  }

  changeEmploy = activeEmployeId => {
    this.setState({activeEmployeId}, this.getComponent)
  }

  changeSalary = activeSalaryId => {
    this.setState({activeSalaryId}, this.getComponent)
  }

  enterSearchInput = () => {
    this.getComponent()
  }

  changeSearchInput = searchInput => {
    this.setState({searchInput})
  }

  renderLoaderView = () => (
    <div>
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  renderApiSuccessView = () => {
    const {jobsList} = this.state
    return (
      <div className="card">
        <Header />
        <Profile />
        <input placeholder="Search" type="search" data-testid="searchButton" />
        <ul>
          {jobsList.map(each => (
            <JobItem jobDetails={each} key={each.id} />
          ))}
        </ul>
      </div>
    )
  }

  renderApiFailureView = () => (
    <div>
      <div>
        <header />
      </div>
      <img
        alt="failure view"
        src="https://assets.ccbp.in/frontend/react-js/failure-img.png"
      />
      <p>We cannot seem to find the page you are looking for</p>
      <button type="button">Retry</button>
    </div>
  )

  renderAllProducts = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case submitStatus.success:
        return this.renderApiSuccessView()

      case submitStatus.failure:
        return this.renderApiFailureView()

      case submitStatus.inProgress:
        return this.renderLoaderView()

      default:
        return null
    }
  }

  render() {
    const token = Cookies.get('jwt_token')
    if (token === undefined) {
      return <Redirect to="/login" />
    }
    const {searchInput, activeEmployeId, activeSalaryId} = this.state

    return (
      <div>
        <FiltersGroup
          searchInput={searchInput}
          activeEmployeId={activeEmployeId}
          activeSalaryId={activeSalaryId}
          enterSearchInput={this.enterSearchInput}
          clearFilters={this.clearFilters}
          changeSearchInput={this.changeSearchInput}
          salaryRangesList={salaryRangesList}
          changeSalary={this.changeSalary}
          changeEmploy={this.changeEmploy}
          employmentTypesList={employmentTypesList}
        />
        {this.renderAllProducts()}
      </div>
    )
  }
}
export default Jobs
